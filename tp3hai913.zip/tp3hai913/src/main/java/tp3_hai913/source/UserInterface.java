package tp3_hai913.source;

import java.rmi.server.ExportException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import tp3_hai913.UserProfiler;
import tp3_hai913.source.repository.ProductRepository;

import java.util.Scanner;

public class UserInterface {
    private UserProfiler userProfiler;
    private ProductRepository productRepo;
    private User user;

    public UserInterface(UserProfiler userProfiler, ProductRepository productRepo, User user) {
        this.userProfiler = userProfiler;
        this.productRepo = productRepo;
        this.user = user;
    }

    public void start() {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        System.out.println("Bienvenue dans l'application de gestion des produits !");

        while (running) {
            System.out.println("\nSélectionnez une option :");
            System.out.println("1 - Afficher les produits");
            System.out.println("2 - Consulter un produit par ID");
            System.out.println("3 - Ajouter un nouveau produit");
            System.out.println("4 - Supprimer un produit par ID");
            System.out.println("5 - Mettre à jour un produit");
            System.out.println("6 - Quitter");

            String choix = scanner.nextLine();

            switch (choix) {
                case "1":
                    displayProducts();
                    break;
                case "2":
                    getProduct(scanner);
                    break;
                case "3":
                    addProduct(scanner);
                    break;
                case "4":
                    deleteProduct(scanner);
                    break;
                case "5":
                    updateProduct(scanner);
                    break;
                case "6":
                    running = false;
                    break;
                default:
                    System.out.println("Choix non valide, veuillez réessayer.");
            }
        }

        System.out.println("Application terminée.");
        scanner.close();
    }

    private void displayProducts() {
        productRepo.displayAllProducts();
    }

    private void getProduct(Scanner scanner) {
        try {
            System.out.print("Entrez l'ID du produit : ");
            String id = scanner.nextLine();
            Product product = productRepo.getProduct(id);
            userProfiler.updateProfile(user.getId(), "read");
            System.out.println("Produit : " + product);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private void addProduct(Scanner scanner) {
        try {
            System.out.print("Entrez l'ID du produit : ");
            String id = scanner.nextLine();

            // Vérifier si le produit existe déjà
            if (productRepo.getProduct(id) != null) {
                System.out.println("Erreur : Un produit avec cet ID existe déjà.");
                return;
            }

            System.out.print("Entrez le nom du produit : ");
            String name = scanner.nextLine();
            System.out.print("Entrez le prix du produit : ");
            double price = Double.parseDouble(scanner.nextLine());
            System.out.print("Entrez la date d'expiration (aaaa-mm-jj) : ");
            java.time.LocalDate expirationDate = java.time.LocalDate.parse(scanner.nextLine());

            Product product = new Product(id, name, price, expirationDate);
            productRepo.addProduct(product);
            userProfiler.updateProfile(user.getId(), "write");
            System.out.println("Produit ajouté avec succès.");
        } catch (NumberFormatException e) {
            System.out.println("Erreur : Veuillez entrer un nombre valide pour le prix.");
        } catch (java.time.format.DateTimeParseException e) {
            System.out.println("Erreur : Veuillez entrer une date valide au format aaaa-mm-jj.");
        } catch (Exception e) {
            System.out.println("Erreur inattendue lors de l'ajout du produit : " + e.getMessage());
        }
    }


    private void deleteProduct(Scanner scanner) {
        try {
            System.out.print("Entrez l'ID du produit à supprimer : ");
            String id = scanner.nextLine();
            productRepo.deleteProduct(id);
            userProfiler.updateProfile(user.getId(), "delete");
            System.out.println("Produit supprimé avec succès.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private void updateProduct(Scanner scanner) {
        try {
            System.out.print("Entrez l'ID du produit à mettre à jour : ");
            String id = scanner.nextLine();
            System.out.print("Entrez le nouveau nom du produit : ");
            String name = scanner.nextLine();
            System.out.print("Entrez le nouveau prix du produit : ");
            double price = Double.parseDouble(scanner.nextLine());
            System.out.print("Entrez la nouvelle date d'expiration (aaaa-mm-jj) : ");
            java.time.LocalDate expirationDate = java.time.LocalDate.parse(scanner.nextLine());

            Product updatedProduct = new Product(id, name, price, expirationDate);
            productRepo.updateProduct(id, updatedProduct);
            userProfiler.updateProfile(user.getId(), "update");
            System.out.println("Produit mis à jour avec succès.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}



