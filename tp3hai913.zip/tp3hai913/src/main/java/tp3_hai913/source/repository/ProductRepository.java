package tp3_hai913.source.repository;


import java.util.HashMap;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import tp3_hai913.source.Product;

public class ProductRepository {
    public Map<String, Product> products = new HashMap<>();
    
    private static final Logger logger = LogManager.getLogger(ProductRepository.class); 
   
    public void addProduct(Product product) throws Exception {
        if (products.containsKey(product.getId())) {
            throw new Exception("Product with ID " + product.getId() + " already exists.");
        }
        
        products.put(product.getId(), product);
        logger.info("ajout du produit avec id {} reussit", product.getId());
    }

    public Product getProduct(String id) throws Exception {
        if (!products.containsKey(id)) {
           return null;
        }
        
        logger.info("récupération du produit avec id {} reussit", id);
        
        return products.get(id);
        
      
        
    }

    public void deleteProduct(String id) throws Exception {
        if (!products.containsKey(id)) {
            throw new Exception("Product with ID " + id + " not found.");
        }
        products.remove(id);
        
        logger.info("suppression du produit avec id {} reussit", id);
    }

    public void updateProduct(String id, Product updatedProduct) throws Exception {
        if (!products.containsKey(id)) {
            throw new Exception("Product with ID " + id + " not found.");
        }
        products.put(id, updatedProduct);
        
        logger.info("mise à jour produit avec id {} reussit", id);
        
    }
    
    
    public Product rechercheProduitLePlusCher() {
    	Product ProduitPlusCher = null;
    	for(Product product : products.values()) {
    		if(ProduitPlusCher == null || product.getPrice() > ProduitPlusCher.getPrice()) {
    			ProduitPlusCher = product;
    		}	
    	}
    	 logger.info("Produit le plus cher : {}", ProduitPlusCher);
    	 return ProduitPlusCher;
    }

    public void displayAllProducts() {	
    	if(products.isEmpty()) {
    		logger.info("aucun produits n'est disponible");
    	}
    	else {
    		logger.info("affichage de tous les produits");
    		products.values().forEach(System.out::println);
        
    	}        
}
 
    
    
}

