package tp3_hai913;

import java.io.File;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.UUID;

import org.eclipse.osgi.framework.util.FilePath;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;

import tp3_hai913.source.Product;
import tp3_hai913.source.User;
import tp3_hai913.source.UserInterface;
import tp3_hai913.source.repository.ProductRepository;

public class Main {
	  private static final Logger logger = LogManager.getLogger(Main.class);

    public static void main(String[] args) throws Exception {
    	logger.info("Bienvenue dans l'application de gestion des produits !");
        List<Log> listeLog = new ArrayList<Log>();
        ObjectMapper objectMapper = new ObjectMapper();
        
     // module JavaTimeModule pour gérer les types Java 8 (LocalDate, LocalDateTime, etc.)
        objectMapper.registerModule(new JavaTimeModule());
        
        // Crée un module et ajoute le sérialiseur personnalisé
        SimpleModule module = new SimpleModule();
        module.addSerializer(User.class, new UserSerializer()); 
        objectMapper.registerModule(module); 
       
        
     // Initialiser le gestionnaire de profil utilisateur et le dépôt de produits
        UserProfiler userProfiler = new UserProfiler();
        ProductRepository productRepo = new ProductRepository();

        // Créer des utilisateurs et les ajouter dans le gestionnaire de profil
        for (int i = 1; i <= 10; i++) {
            String userId = String.valueOf(i);
            User user = new User(userId, "User" + i, 20 + i, "user" + i + "@example.com", "password" + i);
            userProfiler.addUserProfile(userId); // Passer uniquement l'ID de l'utilisateur
            
            // Exécuter des scénarios aléatoires pour chaque utilisateur
            executeScenariosForUser(user, userProfiler, productRepo, listeLog);
        }

        // Sauvegarder les profils utilisateurs
       userProfiler.saveProfilesToJSON("src/main/java/tp3_hai913/UserProfile/userProfiles.json");

        // Analyser les profils enregistrés
        UserProfilerAnalyzer userProfilerAnalyzer = new UserProfilerAnalyzer("src/main/java/tp3_hai913/UserProfile/userProfiles.json");
        userProfilerAnalyzer.analyse();
       
        // Sauvegarder les profils utilisateurs dans un fichier JSON
//        List<User> allUsers = userProfiler.getAllUsers();
//        objectMapper.writeValue(new File("users.json"), allUsers);
        

   
    }

    private static void executeScenariosForUser(User user, UserProfiler userProfiler, ProductRepository productRepo, List<Log> listeLog) {
        Random random = new Random();
       
        for (int i = 0; i < 20; i++) { // 20 actions par utilisateur
            int action = random.nextInt(6); 

            try {
            	
                switch (action) {
                    case 0:
                        // Ajouter un produit
                        String productId = UUID.randomUUID().toString();
                        String productName = "Produit" + random.nextInt(100);
                        double price = 10 + random.nextDouble() * 100;
                        LocalDate expirationDate = LocalDate.now().plusDays(random.nextInt(365));
                        Product newProduct = new Product(productId, productName, price, expirationDate);
                        productRepo.addProduct(newProduct);
                        userProfiler.updateProfile(user.getId(), "write");
                        
                        Log logAddProduct = new LogBuilder()
                        		.setAction("write")
                        		.setEvent("addProduct")
                        		.setProduct(newProduct)
                        		.setTimestamp()
                        		.setUser(user)
                        		.build();
                   
                        listeLog.add(logAddProduct);
                        
                  
                        
                        break;

                    case 1:
                        // Consulter un produit
                        if (!productRepo.products.isEmpty()) {
                            
                            String randomProductId = productRepo.products.keySet().stream().findAny().get();
                            
                            // Récupérer le produit en fonction de l'ID
                            try {
                                Product product = productRepo.getProduct(randomProductId); // Passer l'ID à la méthode
                                if (product != null) {
                                    userProfiler.updateProfile(user.getId(), "read");
                                   
                                    
                                    Log logReadProduct = new LogBuilder()
                                            .setAction("expensive_search")
                                            .setEvent("rechercheProduitLePlusCher")
                                            .setProduct(product)
                                            .setTimestamp()
                                            .setUser(user)
                                            .build();
                                    
                                    listeLog.add(logReadProduct);
                                    
                               
                                } else {
                                    logger.warn("Action non définie pour l'utilisateur {}", user.getId());
                                }
                            } catch (Exception e) {
                            	logger.error("Erreur lors de l'exécution de l'action pour l'utilisateur {} : {}", user.getId(), e.getMessage());
                            }
                      
                        }
                        
                        
                        break;

                        
                        
                    case 2:
                        // Supprimer un produit par ID 
                        if (!productRepo.products.isEmpty()) {
                            String randomProductId = productRepo.products.keySet().stream().findAny().get();
                            productRepo.deleteProduct(randomProductId);
                            userProfiler.updateProfile(user.getId(), "delete");
                            
                            ThreadContext.put("action", "delete");
                            ThreadContext.put("event", "deleteProduct");
                      
                        }
                        
                        Log logDeleteProduct = new LogBuilder()
                        		.setAction("delete")
                        		.setEvent("deleteProduct")
                        		.setTimestamp()
                        		.setUser(user)
                        		.build();
                        
                        
                        listeLog.add(logDeleteProduct);
                        
                       
                      
                        break;

                    case 3:
                        // Mettre à jour un produit
                        if (!productRepo.products.isEmpty()) {
                            String randomProductId = productRepo.products.keySet().stream().findAny().get();
                            Product updatedProduct = new Product(
                                    randomProductId,
                                    "UpdatedName" + random.nextInt(100),
                                    20 + random.nextDouble() * 100,
                                    LocalDate.now().plusDays(random.nextInt(365))
                            );
                            productRepo.updateProduct(randomProductId, updatedProduct);
                            userProfiler.updateProfile(user.getId(), "update");
                           
                            
                            Log logUpdateProduct = new LogBuilder()
                            		.setAction("update")
                            		.setEvent("updateProduct")
                            		.setProduct(updatedProduct)
                            		.setTimestamp()
                            		.setUser(user)
                            		.build();
                            
                            listeLog.add(logUpdateProduct);
                            
                          
                        }
                        
                        
                     
                        break;
                        
                    case 4:
                    	if(!productRepo.products.isEmpty()) {
                    	Product produitLePlusCher = productRepo.rechercheProduitLePlusCher();
                    	userProfiler.updateProfile(user.getId(), "expensive_search");
                    	System.out.println("Produit le plus cher: " + produitLePlusCher );
                    	
                    	 Log logExpensiveSearch = new LogBuilder()
                    	            .setAction("expensive_search")
                    	            .setEvent("rechercheProduitLePlusCher")
                    	            .setProduct(produitLePlusCher)
                    	            .setTimestamp()
                    	            .setUser(user)
                    	            .build();
                      
                    	 listeLog.add(logExpensiveSearch);
                    	
                    	
                    
                    }
                    	
                 
                    break;
                    	

                    case 5:
                        // Afficher tous les produits
                        productRepo.displayAllProducts();
                        userProfiler.updateProfile(user.getId(), "read");
                        
                        Log logDisplayAllProducts = new LogBuilder()
                                .setAction("read")
                                .setEvent("displayAllProducts")
                                .setTimestamp()
                                .setUser(user)
                                .build();
                        
                        listeLog.add(logDisplayAllProducts);
                        
                     
                        break;

                    default:
                        logger.warn("Action non definie pour l'utilisateur {}", user.getId());
                        
                      
                }
            } catch (Exception e) {
                logger.error("Erreur lors de l'exécution de l'action pour l'utilisateur {} : {}", user.getId(), e.getMessage());
            }
        }
    }
    
    
    
    



    public static void saveLogsToFile(List<Log> logs, String filePath) throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.writeValue(new File(filePath), logs);
    }
    
    
    
}


