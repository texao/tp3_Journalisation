package tp3_hai913;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class UserProfilerAnalyzer {

    private String jsonPath;

    public UserProfilerAnalyzer(String jsonPath) {
        this.jsonPath = jsonPath;
    }

    public void analyse() throws IOException {
        // Charger les profils depuis le fichier JSON
        Gson gson = new Gson();
        try (BufferedReader reader = Files.newBufferedReader(Paths.get(jsonPath))) {
            Map<String, Map<String, Integer>> profiles = gson.fromJson(reader, new TypeToken<Map<String, Map<String, Integer>>>() {}.getType());

            // Créer des catégories pour les utilisateurs
            Map<String, List<String>> categories = new HashMap<>();
            categories.put("most_read", new ArrayList<>());
            categories.put("most_write", new ArrayList<>());
            categories.put("most_expensive_search", new ArrayList<>());

            // Analyser chaque profil
            for (Map.Entry<String, Map<String, Integer>> entry : profiles.entrySet()) {
                String userId = entry.getKey();
                Map<String, Integer> actions = entry.getValue();

                // Trouver l'action avec la fréquence la plus élevée
                int maxCount = Collections.max(actions.values());
                
                // Ajouter l'utilisateur à chaque catégorie ayant une action avec la fréquence maximale
                if (actions.get("read") == maxCount) {
                    categories.get("most_read").add(userId);
                }
                if (actions.get("write") == maxCount) {
                    categories.get("most_write").add(userId);
                }
                if (actions.get("expensive_search") == maxCount) {
                    categories.get("most_expensive_search").add(userId);
                }
            }

            // Afficher les résultats
            System.out.println("Utilisateurs qui lisent principalement : " + categories.get("most_read"));
            System.out.println("Utilisateurs qui écrivent principalement : " + categories.get("most_write"));
            System.out.println("Utilisateurs qui recherchent principalement des produits chers : " + categories.get("most_expensive_search"));
        }
    }
}


