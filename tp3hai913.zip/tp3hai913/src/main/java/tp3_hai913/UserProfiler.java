package tp3_hai913;


import com.fasterxml.jackson.databind.ObjectMapper;

import tp3_hai913.source.User;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

public class UserProfiler {
    private Map<String, Map<String, Integer>> userProfiles = new HashMap<>();

    
 // Ajoute un nouveau profil utilisateur avec un compteur initialisé pour chaque type d'opération
    public void addUserProfile(String userId) {
        userProfiles.putIfAbsent(userId, new HashMap<>());
        // Initialiser les compteurs de chaque type d'opération à 0
        userProfiles.get(userId).put("read", 0);
        userProfiles.get(userId).put("write", 0);
        userProfiles.get(userId).put("expensive_search", 0);
    }
    
    
    // Met à jour le profil d'un utilisateur en fonction de l'opération (lecture/écriture/expensive_search)
    public void updateProfile(String userId, String operationType) {
        userProfiles.putIfAbsent(userId, new HashMap<>());
        Map<String, Integer> profile = userProfiles.get(userId);
        profile.put(operationType, profile.getOrDefault(operationType, 0) + 1);
    }

    // Sauvegarde les profils d'utilisateurs dans un fichier JSON
    public void saveProfilesToJSON(String filePath) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            mapper.writeValue(new File(filePath), userProfiles);
            System.out.println("Profiles saved to " + filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Méthode d'analyse des logs et mise à jour des profils d'utilisateurs
    public void analyzeLogsAndGenerateProfiles(String logFilePath) {
        // Lecture des logs depuis un fichier ou autre source
        // On suppose que vous avez déjà un fichier de logs où chaque ligne représente une action effectuée par un utilisateur


        try {
            List<String> logs = Files.readAllLines(Paths.get(logFilePath));

            for (String log : logs) {
                String[] parts = log.split(" ");
                if (parts.length == 2) {
                    String userId = parts[0];
                    String operationType = parts[1];
                    updateProfile(userId, operationType);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    

    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();

        for (String userId : userProfiles.keySet()) {
            String name = "User " + userId; // C'est une valeur fictive pour l'exemple
            String email = userId + "@example.com"; 
            int age = 25; 
            String password = "password"; 

            // Créer un utilisateur à partir du userId et des autres informations fictives
            User user = new User(userId, name, age, email, password);

            // Ajouter l'utilisateur à la liste
            users.add(user);
        }

        return users;
    }



}
