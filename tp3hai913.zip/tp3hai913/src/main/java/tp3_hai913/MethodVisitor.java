package tp3_hai913;

import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.dom.*;
import org.eclipse.jdt.core.dom.rewrite.ASTRewrite;
import org.eclipse.jdt.core.dom.rewrite.ListRewrite;
import org.eclipse.jface.text.Document;
import org.eclipse.text.edits.TextEdit;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.eclipse.jdt.core.dom.*;

import com.fasterxml.jackson.databind.ObjectMapper;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Map;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import org.eclipse.jdt.core.dom.*;


/*
public class MethodVisitor extends ASTVisitor {
    private final ASTRewrite rewriter;
    private final Map<String, Map<String, Integer>> userProfiles = new HashMap<>();
    private final Map<String, String> logMessages = new HashMap<>();

    public MethodVisitor(ASTRewrite rewriter) {
        this.rewriter = rewriter;
        logMessages.put("getProduct", "read");
        logMessages.put("displayAllProducts", "read");
        logMessages.put("addProduct", "write");
        logMessages.put("updateProduct", "write");
        logMessages.put("deleteProduct", "write");
        logMessages.put("rechercheProduitLePlusCher", "expensive_search");
    }

    @Override
    public boolean visit(MethodDeclaration node) {
        String methodName = node.getName().getIdentifier();
        if (logMessages.containsKey(methodName)) {
            String operationType = logMessages.get(methodName);

            // Simuler un utilisateur aléatoire pour chaque appel
            String userId = "User" + new Random().nextInt(10);

            // Mettre à jour le profil utilisateur
            updateProfile(userId, operationType);

            // Injecter un log dans le code source
            injectLogging(node, "User " + userId + " performed: " + operationType);
        }
        return super.visit(node);
    }

    private void injectLogging(MethodDeclaration method, String logMessage) {
        AST ast = method.getAST();
        MethodInvocation logStatement = ast.newMethodInvocation();
        logStatement.setExpression(ast.newSimpleName("logger"));
        logStatement.setName(ast.newSimpleName("info"));
        StringLiteral message = ast.newStringLiteral();
        message.setLiteralValue(logMessage);
        logStatement.arguments().add(message);

        Statement logStmt = ast.newExpressionStatement(logStatement);

        Block methodBody = method.getBody();
        if (methodBody != null) {
            ListRewrite listRewrite = rewriter.getListRewrite(methodBody, Block.STATEMENTS_PROPERTY);
            listRewrite.insertFirst(logStmt, null);
        }
    }

    private void updateProfile(String userId, String operationType) {
        userProfiles.putIfAbsent(userId, new HashMap<>());
        Map<String, Integer> profile = userProfiles.get(userId);
        profile.put(operationType, profile.getOrDefault(operationType, 0) + 1);
    }

    public void saveProfilesToJSON(String filePath) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            mapper.writeValue(new File(filePath), userProfiles);
            System.out.println("Profiles saved to " + filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void analyzeProfiles() {
        List<String> readProfiles = new ArrayList<>();
        List<String> writeProfiles = new ArrayList<>();
        List<String> expensiveSearchProfiles = new ArrayList<>();

        for (Map.Entry<String, Map<String, Integer>> entry : userProfiles.entrySet()) {
            String userId = entry.getKey();
            Map<String, Integer> profile = entry.getValue();
            int readCount = profile.getOrDefault("read", 0);
            int writeCount = profile.getOrDefault("write", 0);
            int expensiveSearchCount = profile.getOrDefault("expensive_search", 0);

            if (readCount >= writeCount && readCount >= expensiveSearchCount) {
                readProfiles.add(userId);
            } else if (writeCount >= readCount && writeCount >= expensiveSearchCount) {
                writeProfiles.add(userId);
            } else {
                expensiveSearchProfiles.add(userId);
            }
        }

        System.out.println("Profils de lecture : " + readProfiles);
        System.out.println("Profils d'écriture : " + writeProfiles);
        System.out.println("Profils de recherche coûteuse : " + expensiveSearchProfiles);
    }
    


    private static final String JAVA_VERSION = JavaCore.VERSION_1_8;

    private static void processFile(Path filePath) {
        if (Files.notExists(filePath) || !Files.isReadable(filePath)) {
            System.err.println("File does not exist or is not readable: " + filePath);
            return;
        }

        try {
            String sourceCode = readSourceCode(filePath);

            CompilationUnit compilationUnit = parseSourceCode(sourceCode, filePath);

            String modifiedCode = applyRewriter(compilationUnit, sourceCode);

            saveModifiedCode(filePath, modifiedCode);

            System.out.println("Modified file saved to: " + generateOutputFilePath(filePath));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String readSourceCode(Path filePath) throws IOException {
        return new String(Files.readAllBytes(filePath));
    }

    private static CompilationUnit parseSourceCode(String sourceCode, Path filePath) {
        ASTParser parser = ASTParser.newParser(AST.JLS8);
        parser.setSource(sourceCode.toCharArray());
        parser.setUnitName(filePath.getFileName().toString());
        parser.setKind(ASTParser.K_COMPILATION_UNIT);

        Map<String, String> options = JavaCore.getOptions();
        options.put(JavaCore.COMPILER_SOURCE, JAVA_VERSION);
        options.put(JavaCore.COMPILER_COMPLIANCE, JAVA_VERSION);
        options.put(JavaCore.COMPILER_CODEGEN_TARGET_PLATFORM, JAVA_VERSION);
        parser.setCompilerOptions(options);
        parser.setResolveBindings(true);

        return (CompilationUnit) parser.createAST(null);
    }

    private static String applyRewriter(CompilationUnit compilationUnit, String sourceCode) throws Exception {
        ASTRewrite rewriter = ASTRewrite.create(compilationUnit.getAST());
        MethodVisitor methodVisitor = new MethodVisitor(rewriter);
        compilationUnit.accept(methodVisitor);

        Document document = new Document(sourceCode);
        TextEdit edits = rewriter.rewriteAST(document, null);
        edits.apply(document);

        return document.get();
    }

    private static void saveModifiedCode(Path filePath, String modifiedCode) throws IOException {
        Path outputFilePath = generateOutputFilePath(filePath);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath.toFile()))) {
            writer.write(modifiedCode);
        }
    }

    private static Path generateOutputFilePath(Path originalFilePath) {
        return Paths.get("Modified_" + originalFilePath.getFileName().toString());
    }


  
  
  public static void main(String[] args) {
    try {
        // Chemin du dossier contenant les fichiers source
        Path sourceDir = Paths.get("src/main/java/tp3_hai913/source");

        // Parcourir récursivement tous les fichiers .java dans le dossier
        Files.walk(sourceDir)
            .filter(path -> Files.isRegularFile(path) && path.toString().endsWith(".java"))
            .forEach(filePath -> processFile(filePath));
    } catch (IOException e) {
        e.printStackTrace();
    }
  }
 
 }
  */
 



public class MethodVisitor extends ASTVisitor {
    private static final Logger logger = LogManager.getLogger(MethodVisitor.class);
    private final ASTRewrite rewriter;
    private final Map<String, Map<String, Integer>> userProfiles = new HashMap<>();

    public MethodVisitor(ASTRewrite rewriter) {
        this.rewriter = rewriter;
    }

    @Override
    public boolean visit(MethodDeclaration node) {
        String methodName = node.getName().getIdentifier();

        // Utiliser Log4j pour gérer les différents types de méthodes
        switch (methodName) {
            case "getProduct":
            case "displayAllProducts":
                logOperation(node, "read");
                break;
            case "addProduct":
            case "updateProduct":
            case "deleteProduct":
                logOperation(node, "write");
                break;
            case "rechercheProduitLePlusCher":
                logOperation(node, "expensive_search");
                break;
            default:
                break;
        }

        return super.visit(node);
    }

    private void logOperation(MethodDeclaration methodNode, String operationType) {
        // Simuler un utilisateur aléatoire pour chaque appel
        String userId = "User" + new Random().nextInt(10);

        // Mettre à jour le profil utilisateur
        updateProfile(userId, operationType);

        // Utiliser Log4j pour enregistrer le log
        logger.info("User {} performed: {} operation in method {}", userId, operationType, methodNode.getName().getIdentifier());

        // Injecter un log dans le code source
        injectLogging(methodNode, "User " + userId + " performed: " + operationType);
    }

    private void injectLogging(MethodDeclaration method, String logMessage) {
        AST ast = method.getAST();
        MethodInvocation logStatement = ast.newMethodInvocation();
        logStatement.setExpression(ast.newSimpleName("logger"));
        logStatement.setName(ast.newSimpleName("info"));
        StringLiteral message = ast.newStringLiteral();
        message.setLiteralValue(logMessage);
        logStatement.arguments().add(message);

        Statement logStmt = ast.newExpressionStatement(logStatement);

        Block methodBody = method.getBody();
        if (methodBody != null) {
            ListRewrite listRewrite = rewriter.getListRewrite(methodBody, Block.STATEMENTS_PROPERTY);
            listRewrite.insertFirst(logStmt, null);
        }
    }

    private void updateProfile(String userId, String operationType) {
        userProfiles.putIfAbsent(userId, new HashMap<>());
        Map<String, Integer> profile = userProfiles.get(userId);
        profile.put(operationType, profile.getOrDefault(operationType, 0) + 1);
    }

    public void saveProfilesToJSON(String filePath) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            mapper.writeValue(new File(filePath), userProfiles);
            System.out.println("Profiles saved to " + filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void analyzeProfiles() {
        List<String> readProfiles = new ArrayList<>();
        List<String> writeProfiles = new ArrayList<>();
        List<String> expensiveSearchProfiles = new ArrayList<>();

        for (Map.Entry<String, Map<String, Integer>> entry : userProfiles.entrySet()) {
            String userId = entry.getKey();
            Map<String, Integer> profile = entry.getValue();
            int readCount = profile.getOrDefault("read", 0);
            int writeCount = profile.getOrDefault("write", 0);
            int expensiveSearchCount = profile.getOrDefault("expensive_search", 0);

            if (readCount >= writeCount && readCount >= expensiveSearchCount) {
                readProfiles.add(userId);
            } else if (writeCount >= readCount && writeCount >= expensiveSearchCount) {
                writeProfiles.add(userId);
            } else {
                expensiveSearchProfiles.add(userId);
            }
        }

        System.out.println("Profils de lecture : " + readProfiles);
        System.out.println("Profils d'écriture : " + writeProfiles);
        System.out.println("Profils de recherche coûteuse : " + expensiveSearchProfiles);
    }

    private static final String JAVA_VERSION = JavaCore.VERSION_1_8;

    private static void processFile(Path filePath) {
        if (Files.notExists(filePath) || !Files.isReadable(filePath)) {
            System.err.println("File does not exist or is not readable: " + filePath);
            return;
        }

        try {
            String sourceCode = readSourceCode(filePath);

            CompilationUnit compilationUnit = parseSourceCode(sourceCode, filePath);

            String modifiedCode = applyRewriter(compilationUnit, sourceCode);

            saveModifiedCode(filePath, modifiedCode);

            System.out.println("Modified file saved to: " + generateOutputFilePath(filePath));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String readSourceCode(Path filePath) throws IOException {
        return new String(Files.readAllBytes(filePath));
    }

    private static CompilationUnit parseSourceCode(String sourceCode, Path filePath) {
        ASTParser parser = ASTParser.newParser(AST.JLS8);
        parser.setSource(sourceCode.toCharArray());
        parser.setUnitName(filePath.getFileName().toString());
        parser.setKind(ASTParser.K_COMPILATION_UNIT);

        Map<String, String> options = JavaCore.getOptions();
        options.put(JavaCore.COMPILER_SOURCE, JAVA_VERSION);
        options.put(JavaCore.COMPILER_COMPLIANCE, JAVA_VERSION);
        options.put(JavaCore.COMPILER_CODEGEN_TARGET_PLATFORM, JAVA_VERSION);
        parser.setCompilerOptions(options);
        parser.setResolveBindings(true);

        return (CompilationUnit) parser.createAST(null);
    }

    private static String applyRewriter(CompilationUnit compilationUnit, String sourceCode) throws Exception {
        ASTRewrite rewriter = ASTRewrite.create(compilationUnit.getAST());
        MethodVisitor methodVisitor = new MethodVisitor(rewriter);
        compilationUnit.accept(methodVisitor);

        Document document = new Document(sourceCode);
        TextEdit edits = rewriter.rewriteAST(document, null);
        edits.apply(document);

        return document.get();
    }

    private static void saveModifiedCode(Path filePath, String modifiedCode) throws IOException {
        Path outputFilePath = generateOutputFilePath(filePath);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath.toFile()))) {
            writer.write(modifiedCode);
        }
    }

    private static Path generateOutputFilePath(Path originalFilePath) {
        return Paths.get("Modified_" + originalFilePath.getFileName().toString());
    }

    public static void main(String[] args) {
        try {
            // Chemin du dossier contenant les fichiers source
            Path sourceDir = Paths.get("src/main/java/tp3_hai913/source");

            // Parcourir récursivement tous les fichiers .java dans le dossier
            Files.walk(sourceDir)
                .filter(path -> Files.isRegularFile(path) && path.toString().endsWith(".java"))
                .forEach(filePath -> processFile(filePath));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}