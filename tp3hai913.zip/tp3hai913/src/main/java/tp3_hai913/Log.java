package tp3_hai913;

import tp3_hai913.source.Product;
import tp3_hai913.source.User;
import com.fasterxml.jackson.annotation.JsonProperty;


public class Log {
	
	@JsonProperty("timestamp")
    private String timestamp;
	@JsonProperty("event")
    private String event;
	@JsonProperty("user")
    private User user;
	@JsonProperty("product")
    private Product product;
	@JsonProperty("action")
    private String action;

    public Log(String timestamp, String event, User user, Product product, String action) {
        this.timestamp = timestamp;
        this.event = event;
        this.user = user;
        this.product = product;
        this.action = action;
    }

    @Override
    public String toString() {
        return "Log{" +
                "timestamp='" + timestamp + '\'' +
                ", event='" + event + '\'' +
                ", user=" + user +
                ", product=" + product +
                ", action='" + action + '\'' +
                '}';
    }
}

