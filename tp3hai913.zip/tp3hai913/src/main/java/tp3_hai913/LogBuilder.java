package tp3_hai913;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import tp3_hai913.source.Product;
import tp3_hai913.source.User;

public class LogBuilder {
    private String timestamp;
    private String event;
    private User user;
    private Product product;
    private String action;

    public LogBuilder setTimestamp() {
        this.timestamp = LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME);
        return this;
    }

    public LogBuilder setEvent(String event) {
        this.event = event;
        return this;
    }

    public LogBuilder setUser(User user) {
        this.user = user;
        return this;
    }

    public LogBuilder setProduct(Product product) {
        this.product = product;
        return this;
    }

    public LogBuilder setAction(String action) {
        this.action = action;
        return this;
    }

    public Log build() {
        return new Log(timestamp, event, user, product, action);
    }
}
